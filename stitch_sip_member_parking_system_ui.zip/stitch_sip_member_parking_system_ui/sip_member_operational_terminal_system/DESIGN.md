---
name: SIP-Member Operational & Terminal System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  mono-plate:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  mono-metric:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.75rem
  margin: 1.5rem
  margin-kiosk: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system serves a mission-critical hybrid environment: high-density administrative operations for fleet and subscription parking management, paired with high-contrast, outdoor-grade terminal interfaces for barrier gates. The personality is efficient, vigilant, dependable, and precise.

The visual style blends **Corporate / Modern** enterprise discipline with utility-driven **High-Contrast Digital Hardware cues**. It prioritizes instant cognitive parsing under both bright fluorescent monitoring rooms and harsh outdoor daylight at gate kiosks. The interface avoids unnecessary decorative flourishes, leaning on structured borders, soft tinted badge surfaces, and unmistakable color-coded subscription statuses (Aktif, Segera Berakhir, Kadaluarsa). Microcopy is formatted in concise, authoritative formal Indonesian (Bahasa Indonesia) designed for error-free transactions.

## Colors

The palette establishes strict functional clarity through designated state assignments:

- **Primary (Indigo)**: `#4F46E5` serves as the primary visual anchor for key system actions, navigation links, and administrative focus states. Associated states: Hover `#3730A3`, Surface/Container `#EEF2FF`, Border `#E0E7FF`.
- **Success / Active (Emerald)**: `#10B981` signals active memberships (`Member Aktif`), validated RFID/ANPR plate matches, and successful gate openings. Associated states: Hover `#059669`, Surface `#ECFDF5`.
- **Warning / Expiring (Amber)**: `#F59E0B` flags grace periods and expiring passes (`Segera Berakhir`, `< 7 Hari`). Associated states: Hover `#D97706`, Surface `#FFFBEB`.
- **Danger / Expired (Rose)**: `#EF4444` flags expired subscriptions (`Kadaluarsa`), blacklisted plates, access denials, and sensor failures. Associated states: Hover `#DC2626`, Surface `#FEF2F2`.
- **Neutral (Slate Hierarchy)**: 
  - Text Primary: `#0F172A`
  - Text Secondary: `#334155`
  - Text Muted: `#64748B`
  - Border Default: `#CBD5E1`
  - Background Primary (Canvas): `#F8FAFC`
  - Background Secondary (Sidebar/Tables): `#F1F5F9`
  - Surface White: `#FFFFFF`
- **Gate Terminal Display (Special)**: Deep Matrix Black `#000000` paired with Neon Emerald `#10B981` text exclusively for digital VMS (Variable Message Signs), simulated barrier screens, and numeric rate boards.

## Typography

The typographic hierarchy relies on **Plus Jakarta Sans** for all native UI structures, modal views, table headers, forms, and general analytical reporting. Its geometric proportions deliver rapid reading comfort in complex administrative grids.

A dedicated monospace family (**JetBrains Mono**) is strictly reserved for hardware and operational data strings:
- **Vehicle License Plates (Plat Nomor)**: Displayed with letter spacing `0.05em` using bold weights inside pill containers (e.g., `B 1234 ABC`).
- **Audit Trails**: Transaction IDs, RFID UID codes, timestamp logs (`YYYY-MM-DD HH:mm:ss`), and passcodes.
- **VMS LED Emulators**: Monospaced tabular characters guarantee strict vertical alignment across multi-gate monitoring feeds.

## Layout & Spacing

The layout model balances an operational dense desktop view with touch-safe kiosk requirements:

- **Admin Console Layout**: 12-column responsive fluid grid with fixed 260px navigation sidebar, `1rem` column gutters, and `1.5rem` outer canvas margin. Data tables utilize compact horizontal row padding (`0.75rem`) to maximize visible records per viewport without scroll fatigue.
- **Kiosk / Lane Terminal Layout**: Centered single-column or split 2-panel architecture with `2rem` outer padding, ensuring card tap targets and plate scan visualizers never clip on touch displays.
- **Density Controls**: Standard tables enforce a 44px row height; compact operational monitor views scale down to 36px row heights with strict `0.5rem` vertical cell alignment.

## Elevation & Depth

This system uses a **crisp surface-container strategy with low-contrast borders** rather than deep dramatized drops, preventing blur distortion on low-tier operational monitors:

- **Level 0 (Canvas Base)**: `#F8FAFC` flat surface. No elevation.
- **Level 1 (Card & Section Containers)**: `#FFFFFF` surface bounded by a continuous 1px `#CBD5E1` outline, supported by an ambient low-opacity shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05)`.
- **Level 2 (Popovers, Tooltips, Table Filters)**: `#FFFFFF` with `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)` and `#CBD5E1` border.
- **Level 3 (Modals & Gate Action Drawers)**: `#FFFFFF` elevation with `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`. Backdrop is dimmed using `rgba(15, 23, 42, 0.6)` blur for high focus retention.

## Shapes

The roundedness token level of `2` provides a balanced, contemporary enterprise finish:

- **Inputs, Buttons, and Search Bars**: `0.5rem` (8px) radius. Creates predictable, sharp click/tap areas.
- **Cards, Filter Bars, and Panel Sections**: `0.75rem` to `1rem` (12px to 16px) radius, delivering soft separation between large dashboard components.
- **Modals and Kiosk Touch Cards**: `1.5rem` (24px) radius, framing critical decision flows with approachable elegance.
- **Status Badges & License Plate Capsules**: `9999px` (Full Pill) for badge tags and recognized plate numbers to contrast against rectangular table structures.

## Components

### Buttons
- **Primary**: Background `#4F46E5`, text `#FFFFFF`, rounded 8px (`rounded-md`), padding 10px 16px. Hover: `#3730A3`. Active: `#312E81`. Focus ring: 2px offset with `#4F46E5`.
- **Secondary / Neutral**: Background `#FFFFFF`, border 1px `#CBD5E1`, text `#334155`. Hover: `#F1F5F9`.
- **Gate Override / Emergency Trigger**: Background `#EF4444`, text `#FFFFFF`. Hover: `#DC2626`.

### Badges & Status Chips
- High-visibility status chips with full pill radius, horizontal padding 8px, vertical padding 2px, font size 12px bold:
  - **Aktif**: Background `#ECFDF5`, text `#059669`, border 1px `#A7F3D0`.
  - **Segera Berakhir**: Background `#FFFBEB`, text `#D97706`, border 1px `#FDE68A`.
  - **Kadaluarsa / Diblokir**: Background `#FEF2F2`, text `#DC2626`, border 1px `#FECACA`.

### Form Fields & Inputs
- Standard height 40px, rounded 8px, border 1px `#CBD5E1`, background `#FFFFFF`, text `#0F172A`.
- Placeholder color: `#64748B`.
- Focused state: Border `#4F46E5`, box-shadow `0 0 0 3px #EEF2FF`.
- Number Plate Input: Styled with mono typeface, auto-capitalization, and optional vehicle-category icon prefix (Mobil / Motor).

### Data Tables
- Header row: `#F1F5F9` background, `#334155` uppercase 11px font with tracking `0.05em`, border bottom 1px `#CBD5E1`.
- Row item: `#FFFFFF` alternating or pure white with border-bottom 1px `#E2E8F0`, hover state `#F8FAFC`.
- Action column: Inline icon buttons (Lihat Detail, Perpanjang, Cetak Kartu).

### Hardware & Gate Terminal Cards
- High-contrast kiosk terminal card: Container background `#000000`, border 1px `#334155`, rounded 16px. Contains digital LED emulation typography in `#10B981` (e.g., `SILAKAN MASUK - B 1234 ABC - AKTIF`).