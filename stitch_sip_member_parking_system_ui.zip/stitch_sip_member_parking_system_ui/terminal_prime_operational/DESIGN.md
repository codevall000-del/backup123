---
name: Terminal Prime Operational
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464554'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777586'
  outline-variant: '#c7c4d7'
  surface-tint: '#5148d7'
  primary: '#2a14b4'
  on-primary: '#ffffff'
  primary-container: '#4338ca'
  on-primary-container: '#c1beff'
  inverse-primary: '#c3c0ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#00442d'
  on-tertiary: '#ffffff'
  tertiary-container: '#005e3f'
  on-tertiary-container: '#4ddda2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#100069'
  on-primary-fixed-variant: '#372abf'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system establishes an elevated fintech operational standard, balancing institutional rigor with high-efficiency terminal poise. Designed strictly for high-throughput operational dashboards and member clearing terminals, the aesthetic prioritizes extreme clarity, fast scanning velocity, and pristine spatial separation.

The visual direction merges refined modern minimalism with structured corporate precision. It avoids heavy skeletal lines and decorative distractions, relying instead on clean white floating planes, soft slate structural backdrops, deliberate indigo focal anchors, and razor-sharp typographic contrast to convey authority, institutional trust, and zero-defect accuracy.

## Colors

The system operates exclusively within a pure light-mode spectrum, using cool-cast slate values to eliminate eye fatigue during continuous operational sessions while maximizing contrast ratios for dense data.

- **Primary Canvas & Tier Surfaces**: Base background sits on `#F8FAFC` (Slate-50), with intermediate sub-surfaces on `#F1F5F9` (Slate-100). Active panels, cards, and data matrices sit exclusively on `#FFFFFF` to enforce clear spatial stratification.
- **Brand & Active States**: Primary actions and active interactive states utilize deep indigo `#4338CA`. Focused elements and secondary highlights leverage lighter indigo tints (`#EEF2FF` for low-intensity active indicators, `#6366F1` for interactive hover accents).
- **Functional Semantics**: Transactional health is strictly communicated via disciplined accents: Emerald `#10B981` (settlement confirmed, operational health), Amber `#F59E0B` (queued, threshold warning), and Rose `#EF4444` (breach, rejected order, critical fail).
- **Text & Contrast Hierarchy**: Text avoids muddy grays. `#0F172A` delivers definitive reading focus for metrics and headers, `#334155` commands secondary labels, and `#64748B` anchors supplementary metadata and structural captions.
- **Borders & Partitions**: Structural partitioning uses `#E2E8F0` at 1px thickness without heavy shadows, keeping UI modules clean and separated.

## Typography

The typographic pairing balances geometric authority with dense legibility. 

- **Headlines (Manrope)**: Sculpted geometry in Manrope provides high-contrast titles, metrics, and card headers. Tight tracking (`-0.01em` to `-0.025em`) ensures large financial figures and section headings remain cohesive units without visual drift.
- **Body & Data Grid (Hanken Grotesk)**: Crisp, open apertures and neutral proportions in Hanken Grotesk provide clean scanability across high-density operational rows. Line heights are tuned tightly (`1.4` to `1.5`) to maximize spatial economy without sacrificing legibility.
- **Monospace Overrides**: For monetary quantities, terminal hashes, clearing IDs, and timestamps, tabular monospaced numerals (`JetBrains Mono`) guarantee optical column alignment across changing values.

## Layout & Spacing

The terminal layout follows an operational fluid-grid structure optimized for wide desktop operations with consistent adaptive breakpoints for tablets and field oversight:

- **Desktop (1280px+)**: 12-column layout with fixed side navigation (240px collapsed, 280px expanded), 1.5rem (`24px`) margins, and 1rem (`16px`) gutters. High-density data tables and dual-pane inspector panels maintain unified 16px internal padding.
- **Tablet (768px - 1279px)**: 8-column layout with compact rail navigation (64px), 1.5rem margins, and 1rem gutters. Inspector panes collapse into sliding overlay drawers.
- **Mobile (<768px)**: 4-column flow with 1rem canvas margin. Multi-column financial tables reflow into structured key-value operational cards.

Spatial discipline relies on a rigorous 4px baseline rhythm. Components stick to a compact vertical cadence (`space-sm` for inline controls, `space-lg` for card internal separation) to maximize viewport data density.

## Elevation & Depth

Depth is established primarily through crisp boundary differentiation and ambient light diffusion, avoiding heavy dark drop-shadows that compromise clean light interfaces.

- **Level 0 (Base Canvas)**: `#F8FAFC` flat surface.
- **Level 1 (Cards & Data Tables)**: `#FFFFFF` surface bordered with 1px `#E2E8F0`, elevated by an ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Dropdowns & Popovers)**: `#FFFFFF` surface with 1px `#CBD5E1` border, lifted by `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal Dialogs & Terminal Overlays)**: `#FFFFFF` surface with 1px `#CBD5E1`, anchored by `box-shadow: 0 12px 24px -4px rgba(15, 23, 42, 0.08), 0 4px 8px -2px rgba(15, 23, 42, 0.03)`. Backdrops use a neutral translucent wash: `rgba(15, 23, 42, 0.3)`.

## Shapes

The roundedness scale is anchored at level `2` (0.5rem / 8px for standard containers), achieving a modern, controlled architectural poise that feels polished without appearing overly playful or toy-like.

- **Base Controls (Inputs, Buttons, Badges)**: 0.375rem (`6px`) to 0.5rem (`8px`) corner radius to maintain crisp tabular alignment across control clusters.
- **Containers & Cards**: 0.5rem (`8px`) up to 0.75rem (`12px`) for primary operational panels, framing data grids cleanly without corner clipping.
- **Status Indicators & Avatars**: True circular styling (`rounded-full`) is reserved solely for status indicator dots, round identity badges, and numerical notification pips.

## Components

### Buttons
- **Primary**: Solid deep indigo `#4338CA` background, text `#FFFFFF`, borderless, padding `8px 16px`, height 36px, radius 6px. Hover: `#3730A3`. Active: `#312E81`. Focus-visible: 2px offset with `#4338CA`.
- **Secondary**: Crisp white `#FFFFFF` background, 1px `#E2E8F0` border, text `#0F172A`, font-weight 500. Hover: `#F8FAFC` and border `#CBD5E1`.
- **Tertiary / Ghost**: Transparent background, text `#334155`. Hover: `#F1F5F9`, text `#0F172A`.
- **Destructive**: Rose tint `#FEF2F2` background, 1px `#FECACA` border, text `#DC2626`. Hover: `#FEE2E2`.

### Inputs & Form Controls
- **Text & Select Fields**: Height 36px, background `#FFFFFF`, 1px `#E2E8F0` border, radius 6px, padding `0 12px`, text `#0F172A`, placeholder `#94A3B8`. Hover: border `#CBD5E1`. Focus: border `#4338CA`, outline `2px solid rgba(67, 56, 202, 0.15)`.
- **Checkboxes & Radios**: 16px dimension, radius 4px (checkbox) or circle (radio), 1.5px `#CBD5E1` border. Checked: background `#4338CA`, border `#4338CA`, check icon `#FFFFFF`.

### Chips & Badges
- **Status Chips**: Height 22px, radius 4px, font-size 11px, weight 600, uppercase letter-spacing 0.04em, padding `2px 8px`.
  - *Active / Success*: Background `#ECFDF5`, text `#065F46`, border 1px `#A7F3D0`.
  - *Pending / Warning*: Background `#FFFBEB`, text `#92400E`, border 1px `#FDE68A`.
  - *Breach / Danger*: Background `#FEF2F2`, text `#991B1B`, border 1px `#FECACA`.
  - *Neutral*: Background `#F1F5F9`, text `#334155`, border 1px `#E2E8F0`.

### Cards & Data Panels
- **Structure**: Surface `#FFFFFF`, border 1px `#E2E8F0`, radius 8px, padding 16px or 20px. Header rows feature a bottom border `1px solid #F1F5F9` separating title metadata from the data body.

### Data Grids & Tables
- **Header**: Height 36px, surface `#F8FAFC`, text `#64748B`, font-size 12px, weight 600, uppercase letter-spacing 0.05em, border-bottom 1px `#E2E8F0`.
- **Rows**: Height 44px, surface `#FFFFFF`, border-bottom 1px `#F1F5F9`, text `#0F172A`, font-size 13px. Hover: background `#F8FAFC`.
- **Numeric Cells**: Right-aligned, formatted with JetBrains Mono, text `#0F172A`.